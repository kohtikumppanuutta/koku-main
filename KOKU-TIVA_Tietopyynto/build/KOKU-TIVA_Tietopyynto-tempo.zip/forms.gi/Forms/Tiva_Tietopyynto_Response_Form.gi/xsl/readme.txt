Place your XSLT documents in this folder.
